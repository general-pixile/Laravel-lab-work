<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RefundController;

Route::get('/', function () {
    return redirect()->route('refunds.index');
});

Route::resource('refunds', RefundController::class);
