<?php

namespace App\Http\Controllers;

use App\Models\Refund;
use Illuminate\Http\Request;

class RefundController extends Controller
{
    public function index()
    {
        $refunds = Refund::latest()->paginate(10);

        return view('refunds.index', compact('refunds'));
    }

    public function create()
    {
        return view('refunds.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:150'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'reason' => ['required', 'string', 'max:1000'],
            'status' => ['required', 'in:Pending,Approved,Rejected'],
        ]);

        $refund = Refund::create($validated);

        return redirect()
            ->route('refunds.show', $refund)
            ->with('success', 'Refund request created successfully.');
    }

    public function show(Refund $refund)
    {
        return view('refunds.show', compact('refund'));
    }

    public function edit(Refund $refund)
    {
        return view('refunds.edit', compact('refund'));
    }

    public function update(Request $request, Refund $refund)
    {
        $validated = $request->validate([
            'customer_name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:150'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'reason' => ['required', 'string', 'max:1000'],
            'status' => ['required', 'in:Pending,Approved,Rejected'],
        ]);

        $refund->update($validated);

        return redirect()
            ->route('refunds.show', $refund)
            ->with('success', 'Refund request updated successfully.');
    }

    public function destroy(Refund $refund)
    {
        $refund->delete();

        return redirect()
            ->route('refunds.index')
            ->with('success', 'Refund request deleted successfully.');
    }
}
