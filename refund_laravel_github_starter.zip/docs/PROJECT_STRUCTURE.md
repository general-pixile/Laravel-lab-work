# Project Structure

Important files included in this starter pack:

```text
app/
  Http/Controllers/RefundController.php
  Models/Refund.php
database/
  migrations/2026_11_19_000000_create_refunds_table.php
resources/
  views/
    layouts/app.blade.php
    refunds/
      _form.blade.php
      index.blade.php
      create.blade.php
      show.blade.php
      edit.blade.php
routes/
  web.php
README.md
```

## CRUD mapping

| Operation | Route name | Controller method |
|---|---|---|
| List | refunds.index | index |
| Show create form | refunds.create | create |
| Save | refunds.store | store |
| View details | refunds.show | show |
| Show edit form | refunds.edit | edit |
| Update | refunds.update | update |
| Delete | refunds.destroy | destroy |
