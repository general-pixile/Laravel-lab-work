<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Refund Management')</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; color: #222; }
        header { background: #183153; color: white; padding: 18px 7%; }
        header a { color: white; text-decoration: none; margin-right: 18px; }
        main { max-width: 1050px; margin: 30px auto; padding: 0 18px; }
        .panel { background: white; padding: 22px; border-radius: 8px; box-shadow: 0 2px 8px #00000010; }
        .btn { display: inline-block; border: 0; border-radius: 5px; padding: 9px 14px; background: #1769aa; color: white; text-decoration: none; cursor: pointer; }
        .btn-danger { background: #b42318; }
        .btn-muted { background: #667085; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; background: white; }
        th, td { text-align: left; padding: 12px; border-bottom: 1px solid #e5e7eb; }
        input, textarea, select { width: 100%; box-sizing: border-box; padding: 10px; margin: 6px 0 14px; border: 1px solid #cbd5e1; border-radius: 5px; }
        label { font-weight: bold; }
        .alert { padding: 12px; border-radius: 5px; margin-bottom: 15px; background: #dcfce7; }
        .error { color: #b42318; font-size: 0.9em; margin-top: -10px; margin-bottom: 10px; }
        .actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
        form.inline { display: inline; }
    </style>
</head>
<body>
<header>
    <strong>Refund Management System</strong>
    <nav style="margin-top: 10px;">
        <a href="{{ route('refunds.index') }}">All Refunds</a>
        <a href="{{ route('refunds.create') }}">Create Refund</a>
    </nav>
</header>
<main>
    @if (session('success'))
        <div class="alert">{{ session('success') }}</div>
    @endif

    @if ($errors->any())
        <div class="alert" style="background:#fee2e2;">
            Please correct the errors in the form.
        </div>
    @endif

    @yield('content')
</main>
</body>
</html>
