@extends('layouts.app')

@section('title', 'Refund Details')

@section('content')
<div class="panel">
    <h2>Refund Details #{{ $refund->id }}</h2>
    <p><strong>Customer:</strong> {{ $refund->customer_name }}</p>
    <p><strong>Email:</strong> {{ $refund->email }}</p>
    <p><strong>Amount:</strong> {{ number_format((float) $refund->amount, 2) }}</p>
    <p><strong>Reason:</strong><br>{{ $refund->reason }}</p>
    <p><strong>Status:</strong> {{ $refund->status }}</p>
    <p><strong>Created:</strong> {{ $refund->created_at->format('d M Y, h:i A') }}</p>
    <div class="actions">
        <a class="btn" href="{{ route('refunds.edit', $refund) }}">Edit Refund</a>
        <a class="btn btn-muted" href="{{ route('refunds.index') }}">Back to List</a>
        <form class="inline" action="{{ route('refunds.destroy', $refund) }}" method="POST" onsubmit="return confirm('Delete this refund request?')">
            @csrf
            @method('DELETE')
            <button class="btn btn-danger" type="submit">Delete</button>
        </form>
    </div>
</div>
@endsection
