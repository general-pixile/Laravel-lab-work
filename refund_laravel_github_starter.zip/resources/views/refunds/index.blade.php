@extends('layouts.app')

@section('title', 'All Refunds')

@section('content')
<div class="panel">
    <div class="actions" style="justify-content:space-between;">
        <h2>Refund Requests</h2>
        <a class="btn" href="{{ route('refunds.create') }}">+ New Refund</a>
    </div>

    @if ($refunds->isEmpty())
        <p>No refund requests have been added yet.</p>
    @else
        <table>
            <thead>
                <tr>
                    <th>ID</th><th>Customer</th><th>Email</th><th>Amount</th><th>Status</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            @foreach ($refunds as $refund)
                <tr>
                    <td>{{ $refund->id }}</td>
                    <td>{{ $refund->customer_name }}</td>
                    <td>{{ $refund->email }}</td>
                    <td>{{ number_format((float) $refund->amount, 2) }}</td>
                    <td>{{ $refund->status }}</td>
                    <td class="actions">
                        <a href="{{ route('refunds.show', $refund) }}">View</a>
                        <a href="{{ route('refunds.edit', $refund) }}">Edit</a>
                        <form class="inline" action="{{ route('refunds.destroy', $refund) }}" method="POST" onsubmit="return confirm('Delete this refund request?')">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div style="margin-top:18px;">{{ $refunds->links() }}</div>
    @endif
</div>
@endsection
