@extends('layouts.app')

@section('title', 'Edit Refund')

@section('content')
<div class="panel">
    <h2>Edit Refund Request #{{ $refund->id }}</h2>
    <form action="{{ route('refunds.update', $refund) }}" method="POST">
        @csrf
        @method('PUT')
        @include('refunds._form')
        <button class="btn" type="submit">Update Refund</button>
        <a class="btn btn-muted" href="{{ route('refunds.show', $refund) }}">Cancel</a>
    </form>
</div>
@endsection
