<div>
    <label for="customer_name">Customer Name</label>
    <input id="customer_name" name="customer_name" value="{{ old('customer_name', $refund->customer_name ?? '') }}" required>
    @error('customer_name') <div class="error">{{ $message }}</div> @enderror

    <label for="email">Email Address</label>
    <input id="email" type="email" name="email" value="{{ old('email', $refund->email ?? '') }}" required>
    @error('email') <div class="error">{{ $message }}</div> @enderror

    <label for="amount">Refund Amount</label>
    <input id="amount" type="number" step="0.01" min="0.01" name="amount" value="{{ old('amount', $refund->amount ?? '') }}" required>
    @error('amount') <div class="error">{{ $message }}</div> @enderror

    <label for="reason">Reason for Refund</label>
    <textarea id="reason" name="reason" rows="4" required>{{ old('reason', $refund->reason ?? '') }}</textarea>
    @error('reason') <div class="error">{{ $message }}</div> @enderror

    <label for="status">Status</label>
    <select id="status" name="status" required>
        @foreach (['Pending', 'Approved', 'Rejected'] as $status)
            <option value="{{ $status }}" @selected(old('status', $refund->status ?? 'Pending') === $status)>{{ $status }}</option>
        @endforeach
    </select>
    @error('status') <div class="error">{{ $message }}</div> @enderror
</div>
