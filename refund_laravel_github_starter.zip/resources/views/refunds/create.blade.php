@extends('layouts.app')

@section('title', 'Create Refund')

@section('content')
<div class="panel">
    <h2>Create Refund Request</h2>
    <form action="{{ route('refunds.store') }}" method="POST">
        @csrf
        @include('refunds._form')
        <button class="btn" type="submit">Save Refund</button>
        <a class="btn btn-muted" href="{{ route('refunds.index') }}">Cancel</a>
    </form>
</div>
@endsection
