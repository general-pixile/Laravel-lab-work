# Refund Management System (Laravel)

A Laravel CRUD project for creating, listing, viewing, editing, and deleting refund requests.

## Features
- Create a refund request
- View all refund requests
- View one refund request
- Edit refund details
- Delete a refund request
- Server-side validation
- MySQL database migration

## Requirements
- PHP 8.2+
- Composer
- Laravel 11 or 12
- MySQL / MariaDB
- Node.js and npm (optional, if you later add frontend assets)

## Installation

1. Create a Laravel project:

   ```bash
   composer create-project laravel/laravel refund-management
   ```

2. Copy the `app`, `database`, `resources`, and `routes` folders from this starter pack into your Laravel project. Merge folders rather than replacing your existing Laravel files.

3. Create a database, for example `refund_management`.

4. Update your `.env` database settings:

   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=refund_management
   DB_USERNAME=root
   DB_PASSWORD=
   ```

5. Generate the application key if needed and run migrations:

   ```bash
   php artisan key:generate
   php artisan migrate
   ```

6. Start the development server:

   ```bash
   php artisan serve
   ```

7. Open `http://127.0.0.1:8000/refunds`.

## GitHub workflow

Run these commands from the root of your Laravel project:

```bash
git init
git add .
git commit -m "Initial Laravel project setup"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/refund-management.git
git push -u origin main
```

After each meaningful task, commit your work:

```bash
git add .
git commit -m "Add refund creation form"
git push
```

Do not upload your real `.env` file, passwords, API keys, or database credentials. Laravel's `.gitignore` should exclude `.env`.

## Suggested development commits

1. `Initial Laravel project setup`
2. `Add refund database migration and model`
3. `Add refund routes and controller`
4. `Create refund listing page`
5. `Add refund creation form and validation`
6. `Add refund details page`
7. `Add refund edit and delete functions`
8. `Improve layout and documentation`

Make commits as you complete the work. Do not create fake or backdated commits; your history should show your actual development progress.
